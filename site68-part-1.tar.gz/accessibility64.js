(()=>{'use strict';
function start(){
 const roots=[document];for(let i=0;i<roots.length;i++)for(const e of roots[i].querySelectorAll('*'))if(e.shadowRoot)roots.push(e.shadowRoot);
 const luminance=rgb=>{let a=(rgb.match(/[\d.]+/g)||[]).slice(0,3).map(Number);if(a.length!==3)return null;return a.map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((s,v,i)=>s+v*[.2126,.7152,.0722][i],0);};
 const ink=rgb=>{let l=luminance(rgb);return l!==null&&(1.05/(l+.05)<4.5)?'#1a1a1f':'#ffffff';};
 const mirrorCSS='.native-select64{display:inline-grid;position:relative;min-inline-size:0;max-inline-size:100%;vertical-align:middle;font:inherit;line-height:1.5}.native-select64>select{position:absolute!important;inset:0;inline-size:100%!important;block-size:100%!important;max-inline-size:100%!important;opacity:0;z-index:2;cursor:pointer}.native-select-label64{min-inline-size:0;max-inline-size:100%;white-space:normal;overflow-wrap:anywhere;font-weight:700;line-height:1.5;pointer-events:none}.native-select64:focus-within{outline:2px solid #405216;outline-offset:3px;border-radius:12px}';
 for(const scope of roots){
  if(scope!==document){let style=document.createElement('style');style.textContent=mirrorCSS+':host .pack input:checked+span,:host .plan:has(input:checked){color:var(--selected-ink64,#1a1a1f)}:host .subscription-badge{white-space:normal}:host .image-saving{width:auto;height:auto;min-width:4rem;min-height:4rem;max-width:calc(100% - 16px);padding:8px}:host([data-large-text64]) .purchase{grid-template-columns:minmax(0,1fr)}:host([data-large-text64]) .selected-product,:host([data-large-text64]) .purchase-options{grid-column:1}:host([data-large-text64]) .product-visual{width:min(100%,250px);margin-inline:auto}:host([data-large-text64]) .subscription-badge{position:relative;display:table;top:auto;right:auto;max-width:100%;margin:-8px 0 12px auto}:host([data-large-text64]) .guarantee{display:flex;flex-wrap:wrap}:host([data-large-text64]) .guarantee-copy{flex:1 1 10em;min-width:0}:host([data-large-text64]) .plans{gap:20px}';scope.append(style);}
  const selected=scope.querySelector('.options63 button[aria-pressed=true],.plan63.is-selected,.plan[aria-checked=true],.plan:has(input:checked),.pack input:checked+span');
  if(selected)(scope===document?document.body:scope.host).style.setProperty('--selected-ink64',ink(getComputedStyle(selected).backgroundColor));
  for(const e of scope.querySelectorAll('.reasons63,.source-comparison63,.ark-performance-comparison,.ark-reasons-study'))e.style.setProperty('--brand-ink64',ink(getComputedStyle(e).backgroundColor));
  for(const select of scope.querySelectorAll('.billing63 select,.billing select,.billing-pill select')){
   let wrapper=document.createElement('span'),label=document.createElement('span');wrapper.className='native-select64';label.className='native-select-label64';label.setAttribute('aria-hidden','true');select.before(wrapper);wrapper.append(label,select);
   const sync=()=>{label.textContent=select.selectedOptions[0]?.textContent||'';};select.addEventListener('change',sync);new MutationObserver(sync).observe(select,{childList:true,subtree:true,attributes:true,attributeFilter:['selected']});sync();
  }
  for(const b of scope.querySelectorAll('button')){let t=b.textContent.trim();if(!b.querySelector('svg')&&/^[‹›←→]$/.test(t)&&b.hasAttribute('aria-label'))b.innerHTML='<svg class="icon-only64" viewBox="0 0 24 24" aria-hidden="true"><path d="'+(/[‹←]/.test(t)?'m15 5-7 7 7 7':'m9 5 7 7-7 7')+'"/></svg>';}
  for(const icon of scope.querySelectorAll('.faq-plus63'))icon.innerHTML='<svg class="icon-only64" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M12 5v14"/></svg>';
  for(const icon of scope.querySelectorAll('.tile-arrow63'))icon.innerHTML='<svg class="icon-only64" viewBox="0 0 24 24" aria-hidden="true"><path d="M5 19 19 5M5 5h14v14"/></svg>';
 }
 // Only the legacy pages lack the newer shared-navigation controller.
 if(!document.body.classList.contains('site63'))for(const menu of document.querySelectorAll('.all-pages63')){
  document.addEventListener('click',e=>{if(!menu.contains(e.target))menu.open=false;});menu.addEventListener('keydown',e=>{if(e.key==='Escape'){menu.open=false;menu.querySelector('summary').focus();}});
 }
 for(const table of document.querySelectorAll('.editable-comparison63,.ark-comparison-card')){table.tabIndex=0;table.setAttribute('role','region');table.setAttribute('aria-label','Product comparison. Scroll horizontally if needed.');}
 // Restored footer is a preview form on all routes, including legacy pages
 // without site63.js. Never allow an apparent subscription without delivery.
 for(const form of document.querySelectorAll('.footer-email67'))form.addEventListener('submit',e=>{e.preventDefault();if(form.reportValidity())form.querySelector('[role=status]').hidden=false;});
 const trust=document.querySelector('.footer-trust67 .home-inner67>div');if(trust){trust.tabIndex=0;trust.setAttribute('role','region');trust.setAttribute('aria-label','Why people choose ARK. Scroll for more.');}
 // A one-em sentinel follows actual computed text size, including user enlargement.
 // It changes layout, never the user's font size. No polling or font-size clamp.
 const probe=document.createElement('span');probe.setAttribute('aria-hidden','true');probe.style.cssText='position:fixed;width:1em;height:1em;inset:0 auto auto 0;visibility:hidden;pointer-events:none;font-size:inherit';document.body.append(probe);
 const reflow=()=>{const size=probe.getBoundingClientRect().height,large=size>20,medium=size>=19.5;document.documentElement.classList.toggle('ark-large-text64',large);document.documentElement.classList.toggle('ark-medium-text64',medium);for(const scope of roots.slice(1)){scope.host.toggleAttribute('data-large-text64',large);scope.host.toggleAttribute('data-medium-text64',medium);}};new ResizeObserver(reflow).observe(probe);reflow();document.documentElement.dataset.accessibility64Ready='true';document.dispatchEvent(new Event('ark-accessibility64-ready'));
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
