(()=>{'use strict';
 const reduced=matchMedia('(prefers-reduced-motion:reduce)').matches;
 for(const rail of document.querySelectorAll('[data-home-loop67]')){
  const section=rail.closest('section'),originals=[...rail.children],count=originals.length,buffer=Math.min(count,8),prev=section.querySelector('[data-home-prev67]'),next=section.querySelector('[data-home-next67]'),status=section.querySelector('[data-home-position67]');
  originals.forEach((card,i)=>card.dataset.homeIndex67=i);
  function clone(card){const copy=card.cloneNode(true);copy.dataset.homeClone67='true';copy.setAttribute('aria-hidden','true');copy.querySelectorAll('button,a').forEach(x=>x.tabIndex=-1);return copy;}
  originals.slice(-buffer).forEach(card=>rail.insertBefore(clone(card),originals[0]));originals.slice(0,buffer).forEach(card=>rail.append(clone(card)));
  const cards=[...rail.children];let physical=buffer,timer,settling=false;
  const target=card=>card.offsetLeft-(rail.clientWidth-card.offsetWidth)/2;
  function state(){physical=cards.reduce((best,card,i)=>Math.abs(target(card)-rail.scrollLeft)<Math.abs(target(cards[best])-rail.scrollLeft)?i:best,0);cards.forEach((card,i)=>card.classList.toggle('is-active',i===physical));status.textContent=(Number(cards[physical].dataset.homeIndex67)+1)+' / '+count;prev.disabled=next.disabled=count<2;}
  function settle(){if(settling)return;settling=true;state();const card=cards[physical];if(card.dataset.homeClone67){physical=buffer+Number(card.dataset.homeIndex67);rail.scrollTo({left:target(cards[physical]),behavior:'instant'});state();}settling=false;}
  function go(index,behavior=reduced?'auto':'smooth'){physical=Math.max(0,Math.min(cards.length-1,index));rail.scrollTo({left:target(cards[physical]),behavior});clearTimeout(timer);timer=setTimeout(settle,behavior==='smooth'?180:0);}
  prev.addEventListener('click',()=>{state();go(physical-1);});next.addEventListener('click',()=>{state();go(physical+1);});
  rail.addEventListener('scroll',()=>{state();clearTimeout(timer);timer=setTimeout(settle,140);},{passive:true});
  rail.addEventListener('keydown',event=>{if(event.target!==rail||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;event.preventDefault();state();go(event.key==='Home'?buffer:event.key==='End'?buffer+count-1:physical+(event.key==='ArrowRight'?1:-1));});
  new ResizeObserver(()=>go(buffer+Number(cards[physical].dataset.homeIndex67),'auto')).observe(rail);
  rail.addEventListener('click',event=>{
   const button=event.target.closest('.home-youtube67');if(!button||!/^[\w-]{11}$/.test(button.dataset.youtube||''))return;
   const card=button.closest('.home-video-card67'),index=Number(card.dataset.homeIndex67),realButton=originals[index].querySelector('button'),dialog=document.createElement('dialog'),close=document.createElement('button'),frame=document.createElement('iframe');
   dialog.className='home-video-dialog67';dialog.setAttribute('aria-label','Customer video '+(index+1));close.type='button';close.className='home-video-close67';close.setAttribute('aria-label','Close customer video');close.innerHTML='<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.7"><path d="m6 6 12 12M18 6 6 18"/></svg>';
   frame.src='https://www.youtube-nocookie.com/embed/'+button.dataset.youtube+'?autoplay=1&rel=0&playsinline=1';frame.title='Customer video '+(index+1);frame.allow='autoplay; encrypted-media; picture-in-picture';frame.allowFullscreen=true;dialog.append(close,frame);document.body.append(dialog);close.addEventListener('click',()=>dialog.close());dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});dialog.addEventListener('close',()=>{dialog.remove();go(buffer+index,'auto');realButton.focus();});dialog.showModal();close.focus();
  });
  requestAnimationFrame(()=>go(buffer,'auto'));
 }
})();
